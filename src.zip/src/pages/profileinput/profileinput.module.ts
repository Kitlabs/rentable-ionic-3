import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfileinputPage } from './profileinput';

@NgModule({
  declarations: [
    ProfileinputPage,
  ],
  imports: [
    IonicPageModule.forChild(ProfileinputPage),
  ],
})
export class ProfileinputPageModule {}
