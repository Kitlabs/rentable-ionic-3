import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ModalPlaceautocompletePage } from './modal-placeautocomplete';

@NgModule({
  declarations: [
    ModalPlaceautocompletePage,
  ],
  imports: [
    IonicPageModule.forChild(ModalPlaceautocompletePage),
  ],
})
export class ModalPlaceautocompletePageModule {}
