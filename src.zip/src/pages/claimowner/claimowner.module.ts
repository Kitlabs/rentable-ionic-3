import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ClaimownerPage } from './claimowner';

@NgModule({
  declarations: [
    ClaimownerPage,
  ],
  imports: [
    IonicPageModule.forChild(ClaimownerPage),
  ],
})
export class ClaimownerPageModule {}
