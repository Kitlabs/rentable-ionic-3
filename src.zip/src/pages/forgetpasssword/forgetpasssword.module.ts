import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ForgetpassswordPage } from './forgetpasssword';

@NgModule({
  declarations: [
    ForgetpassswordPage,
  ],
  imports: [
    IonicPageModule.forChild(ForgetpassswordPage),
  ],
})
export class ForgetpassswordPageModule {}
