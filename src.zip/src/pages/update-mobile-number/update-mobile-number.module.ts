import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdateMobileNumberPage } from './update-mobile-number';

@NgModule({
  declarations: [
    UpdateMobileNumberPage,
  ],
  imports: [
    IonicPageModule.forChild(UpdateMobileNumberPage),
  ],
})
export class UpdateMobileNumberPageModule {}
