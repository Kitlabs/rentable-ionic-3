
# Documentation

Please visit this [Github repo](https://github.com/sibizavic/stripe-with-ionic2-docs) for the latest documentation
