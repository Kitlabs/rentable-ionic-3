import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ClaimrenterPage } from './claimrenter';

@NgModule({
  declarations: [
    ClaimrenterPage,
  ],
  imports: [
    IonicPageModule.forChild(ClaimrenterPage),
  ],
})
export class ClaimrenterPageModule {}
