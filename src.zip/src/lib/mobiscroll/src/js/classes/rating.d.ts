import { Slider } from './slider';
import { MbscFormOptions } from './forms';

export class Rating extends Slider {
    constructor(element: any, settings: MbscFormOptions);
}