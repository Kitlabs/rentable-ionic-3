import { mobiscroll } from '../frameworks/angular';
import { MbscRange, MbscRangeOptions, MbscRangeComponent, MbscRangeStartComponent, MbscRangeEndComponent } from '../range.angular';
declare class MbscModule {
}
export { mobiscroll, MbscRange, MbscRangeComponent, MbscRangeStartComponent, MbscRangeEndComponent, MbscRangeOptions, MbscModule };
