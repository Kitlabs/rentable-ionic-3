import { DatetimeBase, MbscDatetimeOptions } from './datetimebase';

export class DateTime extends DatetimeBase {
    constructor(element: any, settings: MbscDatetimeOptions);
}