import { Scroller, MbscScrollerOptions } from '../classes/scroller';

export class List extends Scroller {
    constructor(element: any, settings: MbscScrollerOptions);
}