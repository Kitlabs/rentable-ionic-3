import { mobiscroll } from '../src/js/modules/mobiscroll.angular';
export * from '../src/js/modules/mobiscroll.angular';
import '../src/js/themes/mobiscroll-dark';
import '../src/js/themes/material';
import '../src/js/themes/range-custom-rentable';
import '../src/js/themes/auto-theme';
export default mobiscroll;
